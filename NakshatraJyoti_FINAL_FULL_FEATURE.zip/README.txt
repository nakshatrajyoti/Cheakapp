NAKSHATRA JYOTI — FINAL FULL INTEGRATED BUILD
================================================

यह पैकेज पुराने फीचर्स को हटाकर छोटा version नहीं है। इसमें एक integrated
HTML + CSS + JS structure दिया गया है।

FILES
-----
index.html
style.css
script.js
assets/posters/
assets/acharyas/

IMPORTANT FIREBASE SETUP
------------------------
1. Firebase Console में Authentication खोलें।
2. Sign-in method में Email/Password ENABLE करें।
3. Authentication > Settings > Authorized domains में
   nakshatrajyoti.github.io जोड़ें।
4. GitHub Pages पर index.html, style.css, script.js और assets को उसी
   folder structure में रखें।

LOGIN / REGISTER
----------------
Email/Password authentication Firebase से चलता है।
Register में नाम Firebase user profile के displayName में save होता है।
Password reset भी जोड़ा गया है।

HOME ORDER
----------
1. आज का पोस्टर
2. "आप किस विषय पर मार्गदर्शन चाहते हैं?"
3. Career / Marriage / Muhurat / Education
4. हमारे आचार्य
5. Quick Services

ACCOUNT
-------
अकाउंट के लिए अलग page नहीं बनाया गया है।
ऊपर profile button से right-side account drawer खुलता है।
Theme, Language और Logout वहीं उपलब्ध हैं।

KUNDLI
------
इस build में Kundli form/test result module है।
यह वास्तविक ग्रह-गणना API नहीं है। वास्तविक Kundli API की credentials/API
contract मिलने पर उसी module में integration करना होगा।

POSTERS AND ACHARYAS
--------------------
अपनी वास्तविक images इन folders में रखें:
assets/posters/poster1.jpg
assets/posters/poster2.jpg
assets/posters/poster3.jpg

assets/acharyas/acharya1.jpg
assets/acharyas/acharya2.jpg
assets/acharyas/acharya3.jpg

अगर image नहीं मिले तो poster area fallback दिखा सकता है।

DO NOT MIX OLD JS PARTS
-----------------------
इस ZIP का script.js एक पूरा module है।
पुराने JS Part-1 / Part-2 / Part-3 इसके ऊपर paste न करें।

GITHUB PAGES
------------
Folder contents को repository के published folder में upload करें।
फिर hard refresh करें:
Chrome: Ctrl+Shift+R
Mobile: browser refresh / cache clear

SECURITY NOTE
-------------
Firebase web configuration में apiKey आदि browser-side configuration का
हिस्सा होते हैं। असली secret keys, service-account JSON या admin private
credentials कभी frontend में न रखें।

FUTURE EXTENSIONS
-----------------
इस structure में आगे:
- वास्तविक Kundli API
- appointment/availability
- payment
- Firestore user profiles
- Firestore messages
- Acharya database
- notifications
- multilingual content
- admin panel
जोड़े जा सकते हैं।
