/* ============================================================
   NAKSHATRA JYOTI — FULL INTEGRATED SCRIPT
   Firebase Authentication + Navigation + Account Drawer +
   Theme + Language + Posters + Kundli Test + Messages
============================================================ */

const $ = (id) => document.getElementById(id);
const show = (el) => el && el.classList.remove("hidden");
const hide = (el) => el && el.classList.add("hidden");

const languageScreen = $("languageScreen");
const loginScreen = $("loginScreen");
const mainApp = $("mainApp");

let selectedLanguage = localStorage.getItem("language") || "hi";
let registerMode = false;
let firebaseAuth = null;
let firebaseAuthModule = null;
let firebaseReady = false;
let currentUser = null;

const firebaseConfig = {
  apiKey: "AIzaSyDRNf2BBo6KnjXCfXAaBvq58SDZ7cuVB9w",
  authDomain: "nakshatra-jyoti.firebaseapp.com",
  projectId: "nakshatra-jyoti",
  storageBucket: "nakshatra-jyoti.firebasestorage.app",
  messagingSenderId: "8014602515",
  appId: "1:8014602515:web:848b96e6932d9070a53ae6",
  measurementId: "G-BYK2GJFJD3"
};

function showLanguage(){
  show(languageScreen); hide(loginScreen); hide(mainApp);
}
function showLogin(){
  hide(languageScreen); show(loginScreen); hide(mainApp);
}
function showApp(){
  hide(languageScreen); hide(loginScreen); show(mainApp);
}

document.querySelectorAll(".language").forEach(btn=>{
  btn.addEventListener("click",()=>{
    document.querySelectorAll(".language").forEach(x=>x.classList.remove("active"));
    btn.classList.add("active");
    selectedLanguage = btn.dataset.lang || "hi";
  });
});

$("languageContinue")?.addEventListener("click",()=>{
  localStorage.setItem("language", selectedLanguage);
  showLogin();
});

function setAuthMode(enabled){
  registerMode = enabled;
  const title = $("authTitle");
  const subtitle = $("authSubtitle");
  const nameWrap = $("registerNameWrap");
  const loginBtn = $("loginButton");
  const registerBtn = $("registerButton");
  if(enabled){
    show(nameWrap);
    title.textContent = "नया अकाउंट";
    subtitle.textContent = "अपनी जानकारी भरकर Nakshatra Jyoti से जुड़ें।";
    loginBtn.textContent = "अकाउंट बनाएँ";
    registerBtn.textContent = "पहले से अकाउंट है? लॉगिन करें";
  }else{
    hide(nameWrap);
    title.textContent = "स्वागत है";
    subtitle.textContent = "Nakshatra Jyoti में अपने मार्गदर्शन का सफर शुरू करें।";
    loginBtn.textContent = "लॉगिन करें";
    registerBtn.textContent = "नया अकाउंट बनाएँ";
  }
  showError("");
}

$("registerButton")?.addEventListener("click",()=>setAuthMode(!registerMode));

function setLoginLoading(loading,text){
  const btn=$("loginButton");
  if(!btn)return;
  btn.disabled=loading;
  if(loading){
    btn.dataset.originalText=btn.textContent;
    btn.textContent=text || "कृपया प्रतीक्षा करें...";
  }else{
    btn.textContent=registerMode?"अकाउंट बनाएँ":"लॉगिन करें";
  }
}

function showError(message){
  const box=$("loginError");
  if(box)box.textContent=message||"";
}

function getFirebaseError(error){
  const code=error?.code||"unknown";
  console.error("Firebase:",code,error);
  const map={
    "auth/invalid-api-key":"Firebase API key मान्य नहीं है।",
    "auth/api-key-not-valid":"Firebase API key मान्य नहीं है।",
    "auth/invalid-email":"ईमेल सही नहीं है।",
    "auth/missing-password":"पासवर्ड डालें।",
    "auth/weak-password":"पासवर्ड कम से कम 6 characters का रखें।",
    "auth/email-already-in-use":"यह ईमेल पहले से registered है। Login करें।",
    "auth/invalid-credential":"ईमेल या पासवर्ड गलत है।",
    "auth/user-not-found":"इस ईमेल से कोई अकाउंट नहीं मिला।",
    "auth/wrong-password":"ईमेल या पासवर्ड गलत है।",
    "auth/too-many-requests":"बहुत ज्यादा प्रयास हुए हैं। थोड़ी देर बाद फिर कोशिश करें।",
    "auth/network-request-failed":"Internet connection की समस्या है।",
    "auth/operation-not-allowed":"Firebase में Email/Password provider Enable नहीं है।",
    "auth/unauthorized-domain":"यह वेबसाइट Firebase Authorized Domains में नहीं है।"
  };
  return map[code] || ("Login में समस्या: "+code);
}

async function initializeFirebase(){
  try{
    const appModule=await import("https://www.gstatic.com/firebasejs/12.16.0/firebase-app.js");
    firebaseAuthModule=await import("https://www.gstatic.com/firebasejs/12.16.0/firebase-auth.js");
    const app=appModule.initializeApp(firebaseConfig);
    firebaseAuth=firebaseAuthModule.getAuth(app);
    firebaseReady=true;

    firebaseAuthModule.onAuthStateChanged(firebaseAuth,(user)=>{
      currentUser=user||null;
      if(user){
        showApp();
        updateUserUI(user);
      }else{
        if(!localStorage.getItem("language"))showLanguage();
        else showLogin();
      }
    });
  }catch(error){
    firebaseReady=false;
    console.error(error);
    showError("Firebase connect नहीं हो पाया। Internet और Firebase settings जाँचें।");
  }
}

$("loginButton")?.addEventListener("click",async()=>{
  if(!firebaseReady||!firebaseAuth){
    showError("Firebase अभी तैयार नहीं हुआ है। कुछ सेकंड बाद फिर कोशिश करें।");
    return;
  }

  const email=$("loginEmail")?.value.trim()||"";
  const password=$("loginPassword")?.value||"";

  if(!email){showError("ईमेल डालें।");return;}
  if(!password){showError("पासवर्ड डालें।");return;}

  try{
    setLoginLoading(true,registerMode?"अकाउंट बनाया जा रहा है...":"लॉगिन हो रहा है...");
    if(registerMode){
      const username=$("registerUsername")?.value.trim()||"";
      if(!username){showError("अपना नाम डालें।");return;}
      if(username.length<3){showError("नाम कम से कम 3 अक्षरों का रखें।");return;}
      if(password.length<6){showError("पासवर्ड कम से कम 6 characters का होना चाहिए।");return;}

      const result=await firebaseAuthModule.createUserWithEmailAndPassword(firebaseAuth,email,password);
      await firebaseAuthModule.updateProfile(result.user,{displayName:username});
      currentUser=result.user;
      updateUserUI(result.user);
      showError("");
      showApp();
      toast("अकाउंट सफलतापूर्वक बन गया।");
    }else{
      const result=await firebaseAuthModule.signInWithEmailAndPassword(firebaseAuth,email,password);
      currentUser=result.user;
      updateUserUI(result.user);
      showError("");
      showApp();
      toast("लॉगिन सफल रहा।");
    }
  }catch(error){
    showError(getFirebaseError(error));
  }finally{
    setLoginLoading(false);
  }
});

$("forgotPasswordButton")?.addEventListener("click",async()=>{
  if(!firebaseReady||!firebaseAuth){showError("Firebase तैयार नहीं है।");return;}
  const email=$("loginEmail")?.value.trim()||"";
  if(!email){showError("पहले ईमेल डालें।");return;}
  try{
    await firebaseAuthModule.sendPasswordResetEmail(firebaseAuth,email);
    showError("");
    toast("Password reset email भेज दिया गया है।");
  }catch(error){showError(getFirebaseError(error));}
});

function updateUserUI(user){
  if(!user)return;
  const name=user.displayName||user.email?.split("@")[0]||"User";
  const letter=name.charAt(0).toUpperCase();
  if($("profileLetter"))$("profileLetter").textContent=letter;
  if($("bigProfileLetter"))$("bigProfileLetter").textContent=letter;
  if($("accountName"))$("accountName").textContent=name;
  if($("accountEmail"))$("accountEmail").textContent=user.email||"";
}

async function logout(){
  if(!firebaseReady||!firebaseAuth)return;
  try{
    await firebaseAuthModule.signOut(firebaseAuth);
    closeAccount();
    closeMenu();
    showLogin();
    toast("लॉगआउट हो गया।");
  }catch(error){console.error(error);toast("लॉगआउट में समस्या हुई।");}
}
$("logoutButton")?.addEventListener("click",logout);
$("drawerLogout")?.addEventListener("click",logout);

const sideMenu=$("sideMenu"),menuOverlay=$("menuOverlay");
function openMenu(){sideMenu?.classList.add("open");menuOverlay?.classList.add("show");}
function closeMenu(){sideMenu?.classList.remove("open");menuOverlay?.classList.remove("show");}
$("menuButton")?.addEventListener("click",openMenu);
$("closeMenu")?.addEventListener("click",closeMenu);
menuOverlay?.addEventListener("click",closeMenu);

function openPage(pageName){
  document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));
  const target=$(pageName+"Page");
  if(target)target.classList.add("active");
  document.querySelectorAll(".bottom-nav button").forEach(b=>b.classList.remove("nav-active"));
  document.querySelectorAll(`[data-page="${pageName}"]`).forEach(b=>b.classList.add("nav-active"));
  closeMenu();
  closeAccount();
  window.scrollTo({top:0,behavior:"smooth"});
}

document.querySelectorAll("[data-page]").forEach(button=>{
  button.addEventListener("click",()=>openPage(button.dataset.page));
});

function openAccount(){
  $("accountDrawer")?.classList.add("open");
  $("accountOverlay")?.classList.add("show");
}
function closeAccount(){
  $("accountDrawer")?.classList.remove("open");
  $("accountOverlay")?.classList.remove("show");
}
$("accountButton")?.addEventListener("click",openAccount);
$("accountMenuButton")?.addEventListener("click",()=>{closeMenu();openAccount();});
$("closeAccount")?.addEventListener("click",closeAccount);
$("accountOverlay")?.addEventListener("click",closeAccount);

function applyTheme(){
  const dark=localStorage.getItem("theme")==="dark";
  document.body.classList.toggle("dark",dark);
  if($("themeState"))$("themeState").textContent=dark?"Dark":"Light";
}
function toggleTheme(){
  localStorage.setItem("theme",document.body.classList.contains("dark")?"light":"dark");
  applyTheme();
}
$("themeSetting")?.addEventListener("click",toggleTheme);
$("drawerTheme")?.addEventListener("click",toggleTheme);
applyTheme();

$("languageSetting")?.addEventListener("click",()=>{
  closeMenu();
  showLanguage();
});
$("drawerLanguage")?.addEventListener("click",()=>{
  closeAccount();
  showLanguage();
});

function toast(message){
  const box=$("toast");
  if(!box)return;
  box.textContent=message;
  box.classList.add("show");
  clearTimeout(window.__toastTimer);
  window.__toastTimer=setTimeout(()=>box.classList.remove("show"),2600);
}

/* Poster dots */
const posterSlider=$("posterSlider");
if(posterSlider){
  const frames=[...posterSlider.querySelectorAll(".poster-frame")];
  const dots=$("sliderDots");
  frames.forEach((_,i)=>{
    const d=document.createElement("span");
    d.className="slider-dot"+(i===0?" active":"");
    d.addEventListener("click",()=>frames[i].scrollIntoView({behavior:"smooth",inline:"center"}));
    dots.appendChild(d);
  });
  posterSlider.addEventListener("scroll",()=>{
    const center=posterSlider.scrollLeft+posterSlider.clientWidth/2;
    let best=0,dist=Infinity;
    frames.forEach((f,i)=>{
      const c=f.offsetLeft+f.offsetWidth/2;
      const d=Math.abs(c-center);
      if(d<dist){dist=d;best=i;}
    });
    dots.querySelectorAll(".slider-dot").forEach((d,i)=>d.classList.toggle("active",i===best));
  });
}

/* Acharya preview opens full Acharya page and scrolls to selected card */
document.querySelectorAll("[data-acharya]").forEach(card=>{
  card.addEventListener("click",()=>{
    openPage("acharya");
    setTimeout(()=>$(("acharyaDetail"+card.dataset.acharya))?.scrollIntoView({behavior:"smooth",block:"start"}),80);
  });
});

/* Contact buttons */
document.querySelectorAll('[data-action="contact"]').forEach(btn=>{
  btn.addEventListener("click",()=>toast("यहाँ वास्तविक आचार्य संपर्क नंबर जोड़ें।"));
});

/* Kundli test storage and result */
$("kundliForm")?.addEventListener("submit",(e)=>{
  e.preventDefault();
  const data={
    name:$("kName").value.trim(),
    date:$("kDate").value,
    time:$("kTime").value,
    place:$("kPlace").value.trim()
  };
  if(!data.name||!data.date||!data.time||!data.place)return;
  localStorage.setItem("kundliDraft",JSON.stringify(data));
  const result=$("kundliResult");
  result.innerHTML=`
    <div class="kundli-output">
      <h2>जन्म विवरण तैयार</h2>
      <div class="result-row"><span>नाम</span><strong>${escapeHtml(data.name)}</strong></div>
      <div class="result-row"><span>जन्म तिथि</span><strong>${escapeHtml(data.date)}</strong></div>
      <div class="result-row"><span>जन्म समय</span><strong>${escapeHtml(data.time)}</strong></div>
      <div class="result-row"><span>जन्म स्थान</span><strong>${escapeHtml(data.place)}</strong></div>
      <p class="form-note">वास्तविक ग्रह स्थिति, लग्न, नक्षत्र और भावों की गणना के लिए इस मॉड्यूल में प्रमाणित Kundli API जोड़ी जानी बाकी है।</p>
    </div>`;
  toast("कुंडली के लिए विवरण तैयार हो गया।");
});

/* Messages */
let messages=[];
try{messages=JSON.parse(localStorage.getItem("njMessages")||"[]");}catch{messages=[];}
function renderMessages(){
  const box=$("messageList");
  if(!box)return;
  if(!messages.length){
    box.innerHTML='<div class="message-item"><strong>अभी कोई संदेश नहीं है।</strong><p style="color:var(--muted);margin-top:6px">अपना पहला प्रश्न ऊपर लिखें।</p></div>';
    return;
  }
  box.innerHTML=messages.map(m=>`
    <article class="message-item">
      <strong>आपका प्रश्न</strong>
      <p style="margin-top:8px;white-space:pre-wrap">${escapeHtml(m.text)}</p>
      <time>${escapeHtml(m.time)}</time>
    </article>`).join("");
}
$("messageText")?.addEventListener("input",e=>{
  $("messageCounter").textContent=`${e.target.value.length} / 2000`;
});
$("messageForm")?.addEventListener("submit",e=>{
  e.preventDefault();
  const text=$("messageText").value.trim();
  if(!text){toast("पहले अपना प्रश्न लिखें।");return;}
  messages.unshift({text,time:new Date().toLocaleString("hi-IN")});
  messages=messages.slice(0,30);
  localStorage.setItem("njMessages",JSON.stringify(messages));
  $("messageText").value="";
  $("messageCounter").textContent="0 / 2000";
  renderMessages();
  toast("संदेश सहेज लिया गया।");
});
renderMessages();

function escapeHtml(value){
  return String(value??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
}

/* Keyboard / accessibility */
document.addEventListener("keydown",e=>{
  if(e.key==="Escape"){
    closeMenu();
    closeAccount();
  }
});

/* Restore draft */
try{
  const d=JSON.parse(localStorage.getItem("kundliDraft")||"null");
  if(d){
    if($("kName"))$("kName").value=d.name||"";
    if($("kDate"))$("kDate").value=d.date||"";
    if($("kTime"))$("kTime").value=d.time||"";
    if($("kPlace"))$("kPlace").value=d.place||"";
  }
}catch{}

if(localStorage.getItem("language"))showLogin();else showLanguage();
initializeFirebase();

console.log("Nakshatra Jyoti — FULL INTEGRATED VERSION loaded.");
